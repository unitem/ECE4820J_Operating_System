# ECE482 homework 3

## Author

Name: Weiqing Xu

Student ID: 520021910400
 
## Brief documentation
 
For h3, see /h3 folder. All the non-programming exercises are in /h3/README.md

### Compile and run for programming exercise

```bash
cd /h3
clang 'ex2.c' -o 'ex2' -std=gnu11 -O2 -Wall -Wextra -pedantic -Wno-unused-result -Wconversion -g
./ex2
```